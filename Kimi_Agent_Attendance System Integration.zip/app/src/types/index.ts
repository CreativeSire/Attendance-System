export type UserRole = 'admin' | 'manager' | 'staff';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  department?: string;
  employeeId: string;
  hourlyRate?: number;
  officeLocation?: {
    lat: number;
    lng: number;
    radius: number; // in meters
    address: string;
  };
}

export type AttendanceStatus = 'present' | 'late' | 'absent' | 'on_leave' | 'half_day';

export interface AttendanceRecord {
  id: string;
  userId: string;
  userName: string;
  date: string;
  clockIn?: {
    time: string;
    location: {
      lat: number;
      lng: number;
      address?: string;
    };
    method: 'gps' | 'qr' | 'manual';
  };
  clockOut?: {
    time: string;
    location: {
      lat: number;
      lng: number;
      address?: string;
    };
    method: 'gps' | 'qr' | 'manual';
  };
  status: AttendanceStatus;
  totalHours: number;
  notes?: string;
  approvedBy?: string;
  isLate?: boolean;
  lateMinutes?: number;
}

export interface LeaveRequest {
  id: string;
  userId: string;
  userName: string;
  type: 'sick' | 'vacation' | 'personal' | 'other';
  startDate: string;
  endDate: string;
  reason: string;
  status: 'pending' | 'approved' | 'rejected';
  requestedAt: string;
  approvedBy?: string;
  approvedAt?: string;
}

export interface PayrollData {
  userId: string;
  userName: string;
  period: string;
  totalHours: number;
  regularHours: number;
  overtimeHours: number;
  lateDeductions: number;
  hourlyRate: number;
  totalPay: number;
}

export interface QRSession {
  id: string;
  code: string;
  createdAt: string;
  expiresAt: string;
  location: {
    lat: number;
    lng: number;
  };
}

export interface CompanySettings {
  workStartTime: string;
  workEndTime: string;
  gracePeriodMinutes: number;
  officeLocation: {
    lat: number;
    lng: number;
    radius: number;
    address: string;
  };
  qrCodeRefreshInterval: number; // in minutes
}
