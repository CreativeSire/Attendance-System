import { useEffect, useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useQRCodeGenerator } from '@/hooks/useQRCode';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Clock, 
  MapPin,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { cn } from '@/lib/utils';

export function QRCodeManager() {
  const { user } = useAuth();
  const [isActive] = useState(true);
  
  const officeLocation = user?.officeLocation || { lat: 6.5244, lng: 3.3792 };
  const refreshInterval = 5;
  
  const { 
    currentQR, 
    timeRemaining, 
    startQRGenerator, 
    stopQRGenerator, 
    isValid 
  } = useQRCodeGenerator(officeLocation, refreshInterval);

  useEffect(() => {
    if (isActive) {
      startQRGenerator();
    } else {
      stopQRGenerator();
    }
    
    return () => {
      stopQRGenerator();
    };
  }, [isActive, startQRGenerator, stopQRGenerator]);

  const formatTimeRemaining = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-4 pb-20">
      <div>
        <h2 className="text-xl font-bold text-[#e0e0f0]">QR Code</h2>
        <p className="text-sm text-[#888]">For staff check-in</p>
      </div>

      <Card className="bg-[#1e1e35] border-[#2a2a4a]">
        <CardContent className="p-6">
          <div className="flex flex-col items-center">
            <div className="relative mb-6">
              <div className={cn(
                "p-6 rounded-2xl bg-white transition-all",
                isValid ? "shadow-lg shadow-emerald-500/20" : "opacity-50"
              )}>
                {currentQR && (
                  <QRCodeSVG
                    value={currentQR.code}
                    size={200}
                    level="H"
                    includeMargin={false}
                  />
                )}
              </div>
              
              <div className="absolute -bottom-3 left-1/2 -translate-x-1/2">
                <div className={cn(
                  "px-4 py-1.5 rounded-full shadow-lg flex items-center gap-2",
                  timeRemaining < 30 ? "bg-red-500/20 text-red-400" : "bg-[#1e1e35] text-[#e0e0f0] border border-[#2a2a4a]"
                )}>
                  <Clock className="w-4 h-4" />
                  <span className="text-sm font-medium tabular-nums">
                    {formatTimeRemaining(timeRemaining)}
                  </span>
                </div>
              </div>
            </div>

            <Badge 
              className={cn(
                isValid ? "bg-emerald-500/20 text-emerald-400" : "bg-red-500/20 text-red-400"
              )}
            >
              {isValid ? (
                <><CheckCircle2 className="w-3 h-3 mr-1" /> Valid</>
              ) : (
                <><AlertTriangle className="w-3 h-3 mr-1" /> Expired</>
              )}
            </Badge>

            <p className="text-xs text-[#666] mt-4 text-center">
              Display this QR code at the office entrance.<br/>
              Staff can scan it to clock in/out.
            </p>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 gap-3">
        <Card className="bg-[#1e1e35] border-[#2a2a4a]">
          <CardContent className="p-4">
            <MapPin className="w-5 h-5 text-[#6C63FF] mb-2" />
            <p className="text-xs text-[#888]">Location</p>
            <p className="text-sm text-[#e0e0f0]">Lagos, Nigeria</p>
            <p className="text-[10px] text-[#666]">300m radius</p>
          </CardContent>
        </Card>

        <Card className="bg-[#1e1e35] border-[#2a2a4a]">
          <CardContent className="p-4">
            <Clock className="w-5 h-5 text-[#6C63FF] mb-2" />
            <p className="text-xs text-[#888]">Refresh</p>
            <p className="text-sm text-[#e0e0f0]">Every 5 min</p>
            <p className="text-[10px] text-[#666]">Auto-rotates</p>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-amber-500/10 border-amber-500/30">
        <CardContent className="p-4">
          <p className="text-sm text-amber-400">
            <strong>Tip:</strong> Display this on a tablet at the office entrance. 
            The QR code cannot be shared remotely as it refreshes every 5 minutes.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
