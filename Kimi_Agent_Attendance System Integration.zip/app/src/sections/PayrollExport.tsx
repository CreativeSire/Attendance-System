import { useState, useMemo } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { 
  DollarSign, 
  FileSpreadsheet,
  Clock,
  TrendingUp,
  AlertTriangle,
  User,
  Calculator,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { format, subMonths } from 'date-fns';
import * as XLSX from 'xlsx';
import { cn } from '@/lib/utils';

interface PayrollExportProps {
  attendance: any;
}

interface PayrollEntry {
  userId: string;
  userName: string;
  department: string;
  period: string;
  presentDays: number;
  totalHours: number;
  lateCount: number;
  dailyRate: number;
  grossPay: number;
  latePenalty: number;
  netPay: number;
  monthlySalary: number;
}

export function PayrollExport({ attendance }: PayrollExportProps) {
  const { employees } = useAuth();
  const { toast } = useToast();
  const [selectedPeriod, setSelectedPeriod] = useState<string>(format(new Date(), 'yyyy-MM'));
  const [selectedEmployee, setSelectedEmployee] = useState<string>('all');
  const [detailsOpen, setDetailsOpen] = useState(false);

  const payrollData: PayrollEntry[] = useMemo(() => {
    if (selectedEmployee !== 'all') {
      const emp = employees.find(e => e.id === selectedEmployee);
      if (emp && emp.hourlyRate) {
        const monthlySalary = emp.hourlyRate * 8 * attendance.WORKING_DAYS_PER_MONTH;
        const calc = attendance.calculatePayroll(emp.id, monthlySalary, selectedPeriod);
        return [{
          ...calc,
          department: emp.department || '',
          period: selectedPeriod
        }];
      }
      return [];
    }

    return employees
      .filter(emp => emp.hourlyRate)
      .map(emp => {
        const monthlySalary = (emp.hourlyRate || 0) * 8 * attendance.WORKING_DAYS_PER_MONTH;
        const calc = attendance.calculatePayroll(emp.id, monthlySalary, selectedPeriod);
        return {
          ...calc,
          department: emp.department || '',
          period: selectedPeriod
        };
      });
  }, [attendance, employees, selectedPeriod, selectedEmployee]);

  const totals = useMemo(() => {
    return payrollData.reduce((acc, entry) => ({
      presentDays: acc.presentDays + entry.presentDays,
      totalHours: acc.totalHours + entry.totalHours,
      lateCount: acc.lateCount + entry.lateCount,
      grossPay: acc.grossPay + entry.grossPay,
      latePenalty: acc.latePenalty + entry.latePenalty,
      netPay: acc.netPay + entry.netPay
    }), {
      presentDays: 0,
      totalHours: 0,
      lateCount: 0,
      grossPay: 0,
      latePenalty: 0,
      netPay: 0
    });
  }, [payrollData]);

  const periodOptions = useMemo(() => {
    const options = [];
    for (let i = 0; i < 6; i++) {
      const date = subMonths(new Date(), i);
      const value = format(date, 'yyyy-MM');
      const label = format(date, 'MMMM yyyy');
      options.push({ value, label });
    }
    return options;
  }, []);

  const exportToExcel = () => {
    const exportData = payrollData.map(entry => ({
      'Employee': entry.userName,
      'Department': entry.department,
      'Days': entry.presentDays,
      'Hours': entry.totalHours.toFixed(1),
      'Late Days': entry.lateCount,
      'Daily Rate': `₦${entry.dailyRate.toLocaleString()}`,
      'Gross': `₦${entry.grossPay.toLocaleString()}`,
      'Penalty': `₦${entry.latePenalty.toLocaleString()}`,
      'Net Pay': `₦${entry.netPay.toLocaleString()}`
    }));

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Payroll');
    
    const fileName = `payroll-${selectedPeriod}.xlsx`;
    XLSX.writeFile(wb, fileName);
    
    toast('Excel file downloaded', 'success');
  };

  return (
    <div className="space-y-4 pb-20">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-[#e0e0f0]">Payroll</h2>
          <p className="text-sm text-[#888]">{format(new Date(selectedPeriod + '-01'), 'MMMM yyyy')}</p>
        </div>
        <Button 
          onClick={exportToExcel}
          className="bg-[#6C63FF] hover:bg-[#5a52d5]"
        >
          <FileSpreadsheet className="w-4 h-4 mr-1" />
          Export
        </Button>
      </div>

      <Card className="bg-gradient-to-br from-emerald-500/20 to-emerald-600/10 border-emerald-500/30">
        <CardContent className="p-6 text-center">
          <p className="text-sm text-emerald-400 mb-1">Total Payroll</p>
          <p className="text-4xl font-bold text-emerald-400">
            ₦{totals.netPay.toLocaleString()}
          </p>
          <p className="text-xs text-[#888] mt-2">
            {payrollData.length} employees
          </p>
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 gap-3">
        {[
          { label: 'Gross', value: `₦${totals.grossPay.toLocaleString()}`, icon: DollarSign, color: 'text-[#e0e0f0]' },
          { label: 'Penalties', value: `₦${totals.latePenalty.toLocaleString()}`, icon: AlertTriangle, color: 'text-red-400' },
          { label: 'Hours', value: totals.totalHours.toFixed(0), icon: Clock, color: 'text-blue-400' },
          { label: 'Late Days', value: totals.lateCount, icon: TrendingUp, color: 'text-amber-400' },
        ].map((stat, i) => (
          <Card key={i} className="bg-[#1e1e35] border-[#2a2a4a]">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-[#888]">{stat.label}</p>
                  <p className={cn("text-lg font-bold", stat.color)}>{stat.value}</p>
                </div>
                <stat.icon className={cn("w-5 h-5 opacity-50", stat.color)} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="bg-[#1e1e35] border-[#2a2a4a]">
        <CardContent className="p-4 space-y-3">
          <div className="space-y-2">
            <Label className="text-xs text-[#888]">Period</Label>
            <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
              <SelectTrigger className="bg-[#0f0f1a] border-[#2a2a4a] text-[#e0e0f0]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-[#1e1e35] border-[#2a2a4a]">
                {periodOptions.map(option => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label className="text-xs text-[#888]">Employee</Label>
            <Select value={selectedEmployee} onValueChange={setSelectedEmployee}>
              <SelectTrigger className="bg-[#0f0f1a] border-[#2a2a4a] text-[#e0e0f0]">
                <SelectValue placeholder="All" />
              </SelectTrigger>
              <SelectContent className="bg-[#1e1e35] border-[#2a2a4a]">
                <SelectItem value="all">All Employees</SelectItem>
                {employees.map(emp => (
                  <SelectItem key={emp.id} value={emp.id}>{emp.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <div>
        <button 
          onClick={() => setDetailsOpen(!detailsOpen)}
          className="flex items-center justify-between w-full mb-3"
        >
          <h3 className="font-medium text-[#e0e0f0]">Employee Details</h3>
          {detailsOpen ? <ChevronUp className="w-5 h-5 text-[#888]" /> : <ChevronDown className="w-5 h-5 text-[#888]" />}
        </button>

        {detailsOpen && (
          <div className="space-y-3">
            {payrollData.map((entry) => (
              <Card key={entry.userId} className="bg-[#1e1e35] border-[#2a2a4a]">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-[#2a2a4a] flex items-center justify-center">
                        <User className="w-5 h-5 text-[#6C63FF]" />
                      </div>
                      <div>
                        <p className="font-medium text-[#e0e0f0]">{entry.userName}</p>
                        <p className="text-xs text-[#888]">{entry.department}</p>
                      </div>
                    </div>
                    <p className="text-lg font-bold text-emerald-400">
                      ₦{entry.netPay.toLocaleString()}
                    </p>
                  </div>

                  <div className="grid grid-cols-4 gap-2 text-center pt-3 border-t border-[#2a2a4a]">
                    <div>
                      <p className="text-xs text-[#666]">Days</p>
                      <p className="text-sm font-medium text-[#e0e0f0]">{entry.presentDays}</p>
                    </div>
                    <div>
                      <p className="text-xs text-[#666]">Hours</p>
                      <p className="text-sm font-medium text-[#e0e0f0]">{entry.totalHours.toFixed(1)}</p>
                    </div>
                    <div>
                      <p className="text-xs text-[#666]">Late</p>
                      <p className={cn("text-sm font-medium", entry.lateCount > 0 ? "text-amber-400" : "text-[#e0e0f0]")}>
                        {entry.lateCount}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-[#666]">Gross</p>
                      <p className="text-sm font-medium text-[#e0e0f0]">₦{entry.grossPay.toLocaleString()}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      <Card className="bg-[#1e1e35] border-[#2a2a4a]">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Calculator className="w-5 h-5 text-[#6C63FF] flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-medium text-[#e0e0f0] text-sm">How it works</p>
              <ul className="text-xs text-[#888] mt-2 space-y-1">
                <li>Daily Rate = Monthly Salary ÷ 22 days</li>
                <li>Late Penalty = 10% of daily rate per late day</li>
                <li>Net Pay = Gross Pay - Penalties</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
