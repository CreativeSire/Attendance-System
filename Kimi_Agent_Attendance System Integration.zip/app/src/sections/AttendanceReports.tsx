import { useState, useMemo } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { 
  Calendar, 
  FileSpreadsheet,
  Clock,
  AlertTriangle,
  CheckCircle2,
  Search,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { format, parseISO, startOfWeek, endOfWeek } from 'date-fns';
import * as XLSX from 'xlsx';
import { cn } from '@/lib/utils';
import type { AttendanceRecord } from '@/types';

interface AttendanceReportsProps {
  attendance: any;
}

export function AttendanceReports({ attendance }: AttendanceReportsProps) {
  const { user, hasRole, employees } = useAuth();
  const { toast } = useToast();
  const [dateRange, setDateRange] = useState<'today' | 'week' | 'month' | 'custom'>('week');
  const [startDate, setStartDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [endDate, setEndDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [selectedUser, setSelectedUser] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [filtersOpen, setFiltersOpen] = useState(false);

  // Get filtered records
  const filteredRecords = useMemo(() => {
    let records: AttendanceRecord[] = [];
    
    if (hasRole(['admin', 'manager'])) {
      records = attendance.getAllRecords();
    } else {
      records = attendance.getUserRecords(user?.id || '');
    }

    const today = new Date();
    let filterStart = startDate;
    let filterEnd = endDate;

    switch (dateRange) {
      case 'today':
        filterStart = format(today, 'yyyy-MM-dd');
        filterEnd = format(today, 'yyyy-MM-dd');
        break;
      case 'week':
        const weekStart = startOfWeek(today, { weekStartsOn: 1 });
        const weekEnd = endOfWeek(today, { weekStartsOn: 1 });
        filterStart = format(weekStart, 'yyyy-MM-dd');
        filterEnd = format(weekEnd, 'yyyy-MM-dd');
        break;
      case 'month':
        filterStart = format(new Date(today.getFullYear(), today.getMonth(), 1), 'yyyy-MM-dd');
        filterEnd = format(new Date(today.getFullYear(), today.getMonth() + 1, 0), 'yyyy-MM-dd');
        break;
    }

    records = records.filter(r => r.date >= filterStart && r.date <= filterEnd);

    if (selectedUser !== 'all') {
      records = records.filter(r => r.userId === selectedUser);
    }

    if (statusFilter !== 'all') {
      records = records.filter(r => r.status === statusFilter);
    }

    if (searchQuery) {
      records = records.filter(r => 
        r.userName.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    return records.sort((a, b) => b.date.localeCompare(a.date));
  }, [attendance, user, hasRole, dateRange, startDate, endDate, selectedUser, statusFilter, searchQuery]);

  // Calculate summary stats
  const summary = useMemo(() => {
    const total = filteredRecords.length;
    const present = filteredRecords.filter(r => r.status === 'present').length;
    const late = filteredRecords.filter(r => r.status === 'late').length;
    const absent = filteredRecords.filter(r => r.status === 'absent').length;
    const totalHours = filteredRecords.reduce((sum, r) => sum + r.totalHours, 0);

    return { total, present, late, absent, totalHours: Math.round(totalHours * 10) / 10 };
  }, [filteredRecords]);

  // Export to Excel
  const exportToExcel = () => {
    const exportData = filteredRecords.map(r => ({
      Date: r.date,
      Employee: r.userName,
      'Clock In': r.clockIn?.time || '--:--',
      'Clock Out': r.clockOut?.time || '--:--',
      'Total Hours': r.totalHours.toFixed(2),
      Status: r.status,
      'Late Minutes': r.lateMinutes || 0,
      Method: r.clockIn?.method || 'N/A'
    }));

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Attendance Report');
    
    const fileName = `attendance-report-${format(new Date(), 'yyyy-MM-dd')}.xlsx`;
    XLSX.writeFile(wb, fileName);
    
    toast('Excel file downloaded', 'success');
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'present':
        return <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">Present</Badge>;
      case 'late':
        return <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">Late</Badge>;
      case 'absent':
        return <Badge className="bg-red-500/20 text-red-400 border-red-500/30">Absent</Badge>;
      default:
        return <Badge variant="outline" className="border-[#2a2a4a] text-[#888]">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-[#e0e0f0]">Reports</h2>
          <p className="text-sm text-[#888]">{filteredRecords.length} records</p>
        </div>
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            onClick={exportToExcel}
            className="flex-1 sm:flex-none border-[#2a2a4a] text-[#e0e0f0] hover:bg-[#2a2a4a]"
          >
            <FileSpreadsheet className="w-4 h-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { label: 'Total', value: summary.total, icon: Calendar, color: 'text-[#e0e0f0]' },
          { label: 'Present', value: summary.present, icon: CheckCircle2, color: 'text-emerald-400' },
          { label: 'Late', value: summary.late, icon: AlertTriangle, color: 'text-amber-400' },
          { label: 'Hours', value: summary.totalHours, icon: Clock, color: 'text-[#6C63FF]' },
        ].map((stat, i) => (
          <Card key={i} className="bg-[#1e1e35] border-[#2a2a4a]">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-[#888]">{stat.label}</p>
                  <p className={cn("text-xl font-bold", stat.color)}>{stat.value}</p>
                </div>
                <stat.icon className={cn("w-5 h-5 opacity-50", stat.color)} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Filters - Collapsible on mobile */}
      <Card className="bg-[#1e1e35] border-[#2a2a4a]">
        <CardContent className="p-4">
          <button 
            onClick={() => setFiltersOpen(!filtersOpen)}
            className="flex items-center justify-between w-full text-left"
          >
            <span className="font-medium text-[#e0e0f0]">Filters</span>
            {filtersOpen ? <ChevronUp className="w-5 h-5 text-[#888]" /> : <ChevronDown className="w-5 h-5 text-[#888]" />}
          </button>
          
          {filtersOpen && (
            <div className="mt-4 space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-xs text-[#888]">Date Range</Label>
                  <Select value={dateRange} onValueChange={(v: any) => setDateRange(v)}>
                    <SelectTrigger className="bg-[#0f0f1a] border-[#2a2a4a] text-[#e0e0f0]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-[#1e1e35] border-[#2a2a4a]">
                      <SelectItem value="today">Today</SelectItem>
                      <SelectItem value="week">This Week</SelectItem>
                      <SelectItem value="month">This Month</SelectItem>
                      <SelectItem value="custom">Custom</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {dateRange === 'custom' && (
                  <>
                    <div className="space-y-2">
                      <Label className="text-xs text-[#888]">Start</Label>
                      <Input 
                        type="date" 
                        value={startDate}
                        onChange={(e) => setStartDate(e.target.value)}
                        className="bg-[#0f0f1a] border-[#2a2a4a] text-[#e0e0f0]"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-xs text-[#888]">End</Label>
                      <Input 
                        type="date" 
                        value={endDate}
                        onChange={(e) => setEndDate(e.target.value)}
                        className="bg-[#0f0f1a] border-[#2a2a4a] text-[#e0e0f0]"
                      />
                    </div>
                  </>
                )}

                {hasRole(['admin', 'manager']) && (
                  <div className="space-y-2">
                    <Label className="text-xs text-[#888]">Employee</Label>
                    <Select value={selectedUser} onValueChange={setSelectedUser}>
                      <SelectTrigger className="bg-[#0f0f1a] border-[#2a2a4a] text-[#e0e0f0]">
                        <SelectValue placeholder="All" />
                      </SelectTrigger>
                      <SelectContent className="bg-[#1e1e35] border-[#2a2a4a]">
                        <SelectItem value="all">All Employees</SelectItem>
                        {employees.map(emp => (
                          <SelectItem key={emp.id} value={emp.id}>{emp.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                <div className="space-y-2">
                  <Label className="text-xs text-[#888]">Status</Label>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="bg-[#0f0f1a] border-[#2a2a4a] text-[#e0e0f0]">
                      <SelectValue placeholder="All" />
                    </SelectTrigger>
                    <SelectContent className="bg-[#1e1e35] border-[#2a2a4a]">
                      <SelectItem value="all">All</SelectItem>
                      <SelectItem value="present">Present</SelectItem>
                      <SelectItem value="late">Late</SelectItem>
                      <SelectItem value="absent">Absent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#666]" />
                <Input 
                  placeholder="Search employee..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 bg-[#0f0f1a] border-[#2a2a4a] text-[#e0e0f0]"
                />
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Records List - Mobile Optimized */}
      <div className="space-y-3">
        {filteredRecords.slice(0, 50).map((record) => (
          <Card key={record.id} className="bg-[#1e1e35] border-[#2a2a4a]">
            <CardContent className="p-4">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#2a2a4a] flex items-center justify-center">
                    <span className="text-sm font-bold text-[#6C63FF]">
                      {record.userName.charAt(0)}
                    </span>
                  </div>
                  <div>
                    <p className="font-medium text-[#e0e0f0]">{record.userName}</p>
                    <p className="text-xs text-[#888]">{format(parseISO(record.date), 'MMM d, yyyy')}</p>
                  </div>
                </div>
                {getStatusBadge(record.status)}
              </div>
              
              <div className="grid grid-cols-3 gap-4 mt-4 pt-4 border-t border-[#2a2a4a]">
                <div className="text-center">
                  <p className="text-xs text-[#666]">In</p>
                  <p className="text-sm font-medium text-[#e0e0f0]">{record.clockIn?.time || '--:--'}</p>
                </div>
                <div className="text-center">
                  <p className="text-xs text-[#666]">Out</p>
                  <p className="text-sm font-medium text-[#e0e0f0]">{record.clockOut?.time || '--:--'}</p>
                </div>
                <div className="text-center">
                  <p className="text-xs text-[#666]">Hours</p>
                  <p className={cn(
                    "text-sm font-medium",
                    record.totalHours >= 8 ? "text-emerald-400" : "text-amber-400"
                  )}>
                    {record.totalHours.toFixed(1)}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
        
        {filteredRecords.length === 0 && (
          <div className="text-center py-12">
            <Calendar className="w-12 h-12 mx-auto mb-3 text-[#666]" />
            <p className="text-[#888]">No records found</p>
          </div>
        )}
      </div>
    </div>
  );
}
