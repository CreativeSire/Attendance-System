import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useAttendance } from '@/hooks/useAttendance';
import { useLocation, isWithinOfficeRadius } from '@/hooks/useLocation';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Clock, 
  MapPin,
  LogOut, 
  User, 
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  Briefcase,
  DollarSign,
  FileSpreadsheet,
  Settings,
  Menu,
  X,
  ChevronRight,
  Home
} from 'lucide-react';
import { format } from 'date-fns';
import { ClockInOut } from './ClockInOut';
import { QRCodeManager } from './QRCodeManager';
import { AttendanceReports } from './AttendanceReports';
import { LeaveManagement } from './LeaveManagement';
import { PayrollExport } from './PayrollExport';
import { BulkAdminActions } from './BulkAdminActions';
import { cn } from '@/lib/utils';

export function Dashboard() {
  const { user, logout, hasRole, employees } = useAuth();
  const attendance = useAttendance();
  const location = useLocation();
  const [activeTab, setActiveTab] = useState('overview');
  const [, setIsWithinRange] = useState<boolean | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Check if user is within office radius
  useEffect(() => {
    if (location.location && user?.officeLocation) {
      const withinRange = isWithinOfficeRadius(
        location.location.lat,
        location.location.lng,
        user.officeLocation.lat,
        user.officeLocation.lng,
        user.officeLocation.radius
      );
      setIsWithinRange(withinRange);
    }
  }, [location.location, user?.officeLocation]);

  const todayRecord = user ? attendance.getTodayRecord(user.id) : undefined;
  const isClockedIn = !!todayRecord?.clockIn && !todayRecord?.clockOut;
  const weeklyReport = attendance.getWeeklyReport(user?.id);
  const todayStr = format(new Date(), 'yyyy-MM-dd');
  const todayRecords = attendance.getAllRecords(todayStr);
  const presentCount = todayRecords.filter((r: any) => r.status === 'present' || r.status === 'late').length;
  const lateCount = todayRecords.filter((r: any) => r.isLate).length;
  const absentCount = employees.length - presentCount;

  // Navigation items
  const navItems = [
    { id: 'overview', label: 'Home', icon: Home },
    { id: 'clock', label: 'Clock In', icon: Clock },
    ...(hasRole(['admin', 'manager']) ? [{ id: 'qr', label: 'QR Code', icon: MapPin }] : []),
    { id: 'reports', label: 'Reports', icon: TrendingUp },
    { id: 'leave', label: 'Leave', icon: Briefcase },
    ...(hasRole(['admin', 'manager']) ? [
      { id: 'payroll', label: 'Payroll', icon: DollarSign },
      { id: 'admin', label: 'Admin', icon: Settings }
    ] : []),
  ];

  // Quick stats for staff
  const staffStats = [
    { title: 'Hours Today', value: todayRecord?.totalHours?.toFixed(1) || '0.0', icon: Clock, color: 'text-[#6C63FF]' },
    { title: 'Weekly', value: weeklyReport[0]?.totalHours?.toFixed(1) || '0.0', icon: TrendingUp, color: 'text-emerald-400' },
    { title: 'Present', value: weeklyReport[0]?.daysPresent?.toString() || '0', icon: CheckCircle2, color: 'text-blue-400' },
    { title: 'Late', value: weeklyReport[0]?.daysLate?.toString() || '0', icon: AlertTriangle, color: 'text-amber-400' },
  ];

  // Admin stats
  const adminStats = [
    { title: 'Present', value: presentCount, color: 'text-emerald-400', bg: 'bg-emerald-500/20' },
    { title: 'Absent', value: absentCount, color: 'text-red-400', bg: 'bg-red-500/20' },
    { title: 'Late', value: lateCount, color: 'text-amber-400', bg: 'bg-amber-500/20' },
    { title: 'Staff', value: employees.length, color: 'text-[#6C63FF]', bg: 'bg-[#6C63FF]/20' },
  ];

  if (!user) return null;

  return (
    <div className="min-h-screen bg-[#0f0f1a]">
      {/* Mobile Header */}
      <header className="bg-[#16162a] border-b border-[#2a2a4a] sticky top-0 z-50">
        <div className="flex items-center justify-between h-16 px-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#6C63FF] to-[#8b5cf6] flex items-center justify-center">
              <Clock className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-[#e0e0f0] text-sm">DALA</h1>
              <p className="text-[10px] text-[#888]">{format(new Date(), 'EEE, MMM d')}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Badge className="bg-[#6C63FF]/20 text-[#6C63FF] border-[#6C63FF]/30 text-xs capitalize">
              {user.role}
            </Badge>
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="text-[#e0e0f0] hover:bg-[#2a2a4a]"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="absolute top-16 left-0 right-0 bg-[#16162a] border-b border-[#2a2a4a] p-4 z-50">
            <div className="space-y-1">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={cn(
                    "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all",
                    activeTab === item.id 
                      ? "bg-[#6C63FF] text-white" 
                      : "text-[#888] hover:bg-[#2a2a4a] hover:text-[#e0e0f0]"
                  )}
                >
                  <item.icon className="w-5 h-5" />
                  <span className="font-medium">{item.label}</span>
                  <ChevronRight className="w-4 h-4 ml-auto" />
                </button>
              ))}
              <div className="border-t border-[#2a2a4a] my-2" />
              <button
                onClick={logout}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-red-400 hover:bg-red-500/10 transition-all"
              >
                <LogOut className="w-5 h-5" />
                <span className="font-medium">Logout</span>
              </button>
            </div>
          </div>
        )}
      </header>

      {/* Desktop Sidebar + Main Content */}
      <div className="flex">
        {/* Desktop Sidebar */}
        <aside className="hidden lg:block w-64 bg-[#16162a] border-r border-[#2a2a4a] min-h-screen sticky top-0">
          <div className="p-4">
            <div className="flex items-center gap-3 mb-8 px-2">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#6C63FF] to-[#8b5cf6] flex items-center justify-center">
                <Clock className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="font-bold text-[#e0e0f0]">DALA</h1>
                <p className="text-xs text-[#888]">Attendance</p>
              </div>
            </div>

            <nav className="space-y-1">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={cn(
                    "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all text-left",
                    activeTab === item.id 
                      ? "bg-[#6C63FF] text-white shadow-lg shadow-[#6C63FF]/20" 
                      : "text-[#888] hover:bg-[#2a2a4a] hover:text-[#e0e0f0]"
                  )}
                >
                  <item.icon className="w-5 h-5" />
                  <span className="font-medium">{item.label}</span>
                </button>
              ))}
            </nav>

            <div className="absolute bottom-4 left-4 right-4">
              <div className="p-4 bg-[#1e1e35] rounded-xl border border-[#2a2a4a]">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#6C63FF]/30 to-[#8b5cf6]/30 flex items-center justify-center">
                    <User className="w-5 h-5 text-[#6C63FF]" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-[#e0e0f0] text-sm truncate">{user.name}</p>
                    <p className="text-xs text-[#888] capitalize">{user.role}</p>
                  </div>
                </div>
                <Button 
                  variant="ghost" 
                  onClick={logout}
                  className="w-full mt-3 text-red-400 hover:text-red-300 hover:bg-red-500/10"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Logout
                </Button>
              </div>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-4 lg:p-8 max-w-7xl">
          {/* Overview Tab */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Welcome */}
              <div>
                <h2 className="text-2xl lg:text-3xl font-bold text-[#e0e0f0]">
                  Good {new Date().getHours() < 12 ? 'Morning' : 'Afternoon'} 👋
                </h2>
                <p className="text-[#888] mt-1">{user.name}</p>
              </div>

              {/* Stats */}
              {hasRole(['admin', 'manager']) ? (
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
                  {adminStats.map((stat, index) => (
                    <Card key={index} className="bg-[#1e1e35] border-[#2a2a4a]">
                      <CardContent className="p-4 text-center">
                        <div className={cn("text-3xl lg:text-4xl font-bold mb-1", stat.color)}>{stat.value}</div>
                        <div className="text-xs text-[#888]">{stat.title}</div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
                  {staffStats.map((stat, index) => (
                    <Card key={index} className="bg-[#1e1e35] border-[#2a2a4a]">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-xs text-[#888]">{stat.title}</p>
                            <p className={cn("text-2xl font-bold", stat.color)}>{stat.value}</p>
                          </div>
                          <stat.icon className={cn("w-6 h-6 opacity-50", stat.color)} />
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}

              {/* Quick Actions */}
              <div className="grid lg:grid-cols-2 gap-4">
                {/* Today's Status */}
                <Card className="bg-[#1e1e35] border-[#2a2a4a]">
                  <CardContent className="p-5">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold text-[#e0e0f0]">
                        {hasRole(['admin', 'manager']) ? "Today's Staff" : "Today's Status"}
                      </h3>
                      <Badge variant="outline" className="border-[#2a2a4a] text-[#888]">
                        {format(new Date(), 'MMM d')}
                      </Badge>
                    </div>

                    {hasRole(['admin', 'manager']) ? (
                      <div className="space-y-2 max-h-64 overflow-y-auto">
                        {employees.map((emp) => {
                          const record = attendance.getTodayRecord(emp.id);
                          return (
                            <div 
                              key={emp.id} 
                              className="flex items-center justify-between p-3 bg-[#0f0f1a] rounded-xl"
                            >
                              <div className="flex items-center gap-3">
                                <div className="w-10 h-10 rounded-full bg-[#2a2a4a] flex items-center justify-center">
                                  <span className="text-sm font-bold text-[#6C63FF]">
                                    {emp.name.charAt(0)}
                                  </span>
                                </div>
                                <div>
                                  <p className="font-medium text-sm text-[#e0e0f0]">{emp.name}</p>
                                  <p className="text-xs text-[#888]">{emp.department}</p>
                                </div>
                              </div>
                              <div className="text-right">
                                <Badge 
                                  className={cn(
                                    "text-xs",
                                    record?.clockIn 
                                      ? (record.isLate ? "bg-amber-500/20 text-amber-400" : "bg-emerald-500/20 text-emerald-400")
                                      : "bg-red-500/20 text-red-400"
                                  )}
                                >
                                  {record?.clockIn ? (record.isLate ? "Late" : "On Time") : "Absent"}
                                </Badge>
                                <p className="text-xs text-[#666] mt-1">
                                  {record?.clockIn?.time || '--:--'}
                                </p>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        {todayRecord ? (
                          <div className="space-y-4">
                            <div className={cn(
                              "w-20 h-20 rounded-full mx-auto flex items-center justify-center",
                              todayRecord.isLate ? "bg-amber-500/20" : "bg-emerald-500/20"
                            )}>
                              {todayRecord.isLate ? (
                                <AlertTriangle className="w-10 h-10 text-amber-400" />
                              ) : (
                                <CheckCircle2 className="w-10 h-10 text-emerald-400" />
                              )}
                            </div>
                            <div>
                              <p className="text-lg font-semibold text-[#e0e0f0]">
                                {todayRecord.isLate ? 'Late Arrival' : 'On Time'}
                              </p>
                              <p className="text-[#888]">
                                Clocked in at {todayRecord.clockIn?.time}
                              </p>
                              {todayRecord.isLate && (
                                <p className="text-amber-400 text-sm mt-1">
                                  {todayRecord.lateMinutes} minutes late
                                </p>
                              )}
                            </div>
                            <Button 
                              onClick={() => setActiveTab('clock')}
                              className="bg-[#6C63FF] hover:bg-[#5a52d5]"
                            >
                              {isClockedIn ? 'Clock Out' : 'View Details'}
                            </Button>
                          </div>
                        ) : (
                          <div>
                            <div className="w-20 h-20 rounded-full bg-[#2a2a4a] mx-auto flex items-center justify-center mb-4">
                              <Clock className="w-10 h-10 text-[#666]" />
                            </div>
                            <p className="text-[#888] mb-4">You haven&apos;t clocked in today</p>
                            <Button 
                              onClick={() => setActiveTab('clock')}
                              className="bg-[#6C63FF] hover:bg-[#5a52d5]"
                            >
                              Clock In Now
                            </Button>
                          </div>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Quick Actions */}
                <Card className="bg-[#1e1e35] border-[#2a2a4a]">
                  <CardContent className="p-5">
                    <h3 className="font-semibold text-[#e0e0f0] mb-4">Quick Actions</h3>
                    <div className="grid grid-cols-2 gap-3">
                      <Button 
                        variant="outline" 
                        onClick={() => setActiveTab('clock')}
                        className="h-auto py-4 flex flex-col items-center gap-2 border-[#2a2a4a] text-[#e0e0f0] hover:bg-[#2a2a4a] rounded-xl"
                      >
                        <Clock className="w-6 h-6 text-[#6C63FF]" />
                        <span className="text-sm">Clock In</span>
                      </Button>
                      <Button 
                        variant="outline" 
                        onClick={() => setActiveTab('leave')}
                        className="h-auto py-4 flex flex-col items-center gap-2 border-[#2a2a4a] text-[#e0e0f0] hover:bg-[#2a2a4a] rounded-xl"
                      >
                        <Briefcase className="w-6 h-6 text-emerald-400" />
                        <span className="text-sm">Leave</span>
                      </Button>
                      <Button 
                        variant="outline" 
                        onClick={() => setActiveTab('reports')}
                        className="h-auto py-4 flex flex-col items-center gap-2 border-[#2a2a4a] text-[#e0e0f0] hover:bg-[#2a2a4a] rounded-xl"
                      >
                        <FileSpreadsheet className="w-6 h-6 text-blue-400" />
                        <span className="text-sm">Reports</span>
                      </Button>
                      {hasRole(['admin', 'manager']) && (
                        <Button 
                          variant="outline" 
                          onClick={() => setActiveTab('payroll')}
                          className="h-auto py-4 flex flex-col items-center gap-2 border-[#2a2a4a] text-[#e0e0f0] hover:bg-[#2a2a4a] rounded-xl"
                        >
                          <DollarSign className="w-6 h-6 text-amber-400" />
                          <span className="text-sm">Payroll</span>
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}

          {/* Other Tabs */}
          {activeTab === 'clock' && (
            <ClockInOut 
              attendance={attendance}
              location={location}
              todayRecord={todayRecord}
            />
          )}

          {activeTab === 'qr' && hasRole(['admin', 'manager']) && <QRCodeManager />}
          {activeTab === 'reports' && <AttendanceReports attendance={attendance} />}
          {activeTab === 'leave' && <LeaveManagement attendance={attendance} />}
          {activeTab === 'payroll' && hasRole(['admin', 'manager']) && <PayrollExport attendance={attendance} />}
          {activeTab === 'admin' && hasRole(['admin', 'manager']) && <BulkAdminActions attendance={attendance} />}
        </main>
      </div>

      {/* Mobile Bottom Navigation */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-[#16162a] border-t border-[#2a2a4a] z-50">
        <div className="flex justify-around items-center h-16">
          {navItems.slice(0, 5).map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={cn(
                "flex flex-col items-center gap-1 py-2 px-3 rounded-lg transition-all",
                activeTab === item.id 
                  ? "text-[#6C63FF]" 
                  : "text-[#666]"
              )}
            >
              <item.icon className={cn("w-5 h-5", activeTab === item.id && "fill-current")} />
              <span className="text-[10px]">{item.label}</span>
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
}
