import { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Clock, 
  MapPin, 
  QrCode,
  Scan,
  AlertTriangle,
  CheckCircle2,
  Loader2,
  Navigation,
  Smartphone,
  LocateFixed,
  Info,
  ChevronRight
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Html5QrcodeScanner } from 'html5-qrcode';
import type { AttendanceRecord } from '@/types';

interface ClockInOutProps {
  attendance: any;
  location: any;
  todayRecord: AttendanceRecord | undefined;
}

export function ClockInOut({ attendance, location, todayRecord }: ClockInOutProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeMethod, setActiveMethod] = useState<'gps' | 'qr'>('gps');
  const [isLoading, setIsLoading] = useState(false);
  const [showScanner, setShowScanner] = useState(false);
  const [, setScanResult] = useState<string | null>(null);
  const [gpsStatus, setGpsStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [userLocation, setUserLocation] = useState<{lat: number; lng: number} | null>(null);
  const [distance, setDistance] = useState<number | null>(null);
  const scannerRef = useRef<Html5QrcodeScanner | null>(null);
  const scannerContainerRef = useRef<HTMLDivElement>(null);

  const isClockedIn = !!todayRecord?.clockIn && !todayRecord?.clockOut;
  const isClockedOut = !!todayRecord?.clockOut;

  // Calculate distance when location updates
  useEffect(() => {
    if (location.location && user?.officeLocation) {
      setUserLocation({ lat: location.location.lat, lng: location.location.lng });
      const dist = location.calculateDistance(
        location.location.lat,
        location.location.lng,
        user.officeLocation.lat,
        user.officeLocation.lng
      );
      setDistance(Math.round(dist));
    }
  }, [location.location, user?.officeLocation]);

  // Get location on mount
  useEffect(() => {
    handleGetLocation();
  }, []);

  const handleGetLocation = async () => {
    setGpsStatus('loading');
    try {
      await location.getCurrentLocation();
      setGpsStatus('success');
    } catch (error) {
      setGpsStatus('error');
      toast('Could not get location. You can still clock in.', 'warning');
    }
  };

  // Handle Clock In/Out - works even without GPS
  const handleClockAction = async () => {
    if (!user) return;
    
    setIsLoading(true);
    try {
      // Use current location if available, otherwise use office location
      const clockLocation = userLocation || { lat: 6.5244, lng: 3.3792 };
      
      if (!isClockedIn) {
        const result = attendance.clockIn(user.id, user.name, clockLocation, gpsStatus === 'success' ? 'gps' : 'web');
        if (result.success) {
          if (result.isLate) {
            toast(`⚠️ Late: You are ${result.lateMinutes} minutes late`, 'warning');
          } else {
            toast('✅ Clocked in successfully!', 'success');
          }
        }
      } else {
        const result = attendance.clockOut(user.id, clockLocation, gpsStatus === 'success' ? 'gps' : 'web');
        if (result.success) {
          toast(`✅ Clocked out! Total hours: ${result.totalHours}`, 'success');
        }
      }
    } catch (error: any) {
      toast(error.message || 'Failed to clock in/out', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  // Initialize QR Scanner
  useEffect(() => {
    if (showScanner && scannerContainerRef.current) {
      scannerRef.current = new Html5QrcodeScanner(
        'qr-reader',
        { 
          qrbox: { width: 250, height: 250 },
          fps: 5,
          aspectRatio: 1
        },
        false
      );

      scannerRef.current.render(
        (decodedText) => {
          setScanResult(decodedText);
          setShowScanner(false);
          handleQRScan(decodedText);
        },
        () => {
          // Silent error for QR scanning
        }
      );
    }

    return () => {
      if (scannerRef.current) {
        scannerRef.current.clear().catch(console.error);
      }
    };
  }, [showScanner]);

  // Handle QR Scan
  const handleQRScan = async (code: string) => {
    if (!user) return;
    
    setIsLoading(true);
    try {
      if (code.length < 10) {
        throw new Error('Invalid QR code');
      }

      const currentLocation = userLocation || { lat: 6.5244, lng: 3.3792 };
      
      if (!isClockedIn) {
        const result = attendance.clockIn(user.id, user.name, currentLocation, 'qr');
        if (result.success) {
          toast('✅ Clocked in via QR!', 'success');
        }
      } else {
        const result = attendance.clockOut(user.id, currentLocation, 'qr');
        if (result.success) {
          toast(`✅ Clocked out! Hours: ${result.totalHours}`, 'success');
        }
      }
      setScanResult(null);
    } catch (error: any) {
      toast(error.message || 'Failed to clock in/out', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusColor = () => {
    if (isClockedOut) return 'from-[#6C63FF] to-[#8b5cf6]';
    if (isClockedIn) return 'from-emerald-500 to-emerald-400';
    return 'from-amber-500 to-amber-400';
  };

  const getStatusText = () => {
    if (isClockedOut) return 'Shift Complete';
    if (isClockedIn) return 'Clocked In';
    return 'Ready to Clock In';
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Large Status Card - Mobile Optimized */}
      <Card className="bg-gradient-to-br from-[#1e1e35] to-[#16162a] border-[#2a2a4a] overflow-hidden">
        <CardContent className="p-6">
          {/* Status Header */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className={cn(
                "w-14 h-14 rounded-2xl flex items-center justify-center bg-gradient-to-br shadow-lg",
                getStatusColor()
              )}>
                <Clock className="w-7 h-7 text-white" />
              </div>
              <div>
                <p className="text-sm text-[#888]">Current Status</p>
                <p className="text-xl font-bold text-[#e0e0f0]">{getStatusText()}</p>
              </div>
            </div>
            <Badge 
              variant={isClockedIn ? 'default' : isClockedOut ? 'secondary' : 'outline'}
              className={cn(
                "px-3 py-1 text-sm",
                isClockedIn && "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
                isClockedOut && "bg-[#6C63FF]/20 text-[#6C63FF] border-[#6C63FF]/30",
                !isClockedIn && !isClockedOut && "border-amber-500/50 text-amber-400"
              )}
            >
              {todayRecord?.totalHours?.toFixed(1) || '0.0'}h
            </Badge>
          </div>

          {/* Time Display */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="bg-[#0f0f1a] rounded-xl p-4 text-center">
              <p className="text-xs text-[#666] mb-1">Clock In</p>
              <p className="text-2xl font-bold text-[#e0e0f0]">
                {todayRecord?.clockIn?.time || '--:--'}
              </p>
            </div>
            <div className="bg-[#0f0f1a] rounded-xl p-4 text-center">
              <p className="text-xs text-[#666] mb-1">Clock Out</p>
              <p className="text-2xl font-bold text-[#e0e0f0]">
                {todayRecord?.clockOut?.time || '--:--'}
              </p>
            </div>
          </div>

          {/* Location Status */}
          <div className="flex items-center gap-3 p-3 bg-[#0f0f1a] rounded-xl mb-4">
            <div className={cn(
              "w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0",
              gpsStatus === 'success' ? "bg-emerald-500/20" : 
              gpsStatus === 'loading' ? "bg-amber-500/20" : "bg-[#2a2a4a]"
            )}>
              {gpsStatus === 'loading' ? (
                <Loader2 className="w-5 h-5 text-amber-400 animate-spin" />
              ) : gpsStatus === 'success' ? (
                <LocateFixed className="w-5 h-5 text-emerald-400" />
              ) : (
                <MapPin className="w-5 h-5 text-[#666]" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-[#e0e0f0]">
                {gpsStatus === 'success' ? 'Location confirmed' : 
                 gpsStatus === 'loading' ? 'Getting location...' : 'Location unavailable'}
              </p>
              <p className="text-xs text-[#888] truncate">
                {distance !== null ? `${distance}m from office` : 'Tap to refresh location'}
              </p>
            </div>
            <Button 
              size="sm" 
              variant="ghost" 
              onClick={handleGetLocation}
              disabled={gpsStatus === 'loading'}
              className="flex-shrink-0 text-[#6C63FF] hover:text-[#8b5cf6] hover:bg-[#6C63FF]/10"
            >
              <Navigation className="w-4 h-4" />
            </Button>
          </div>

          {/* Main Action Button - Large Touch Target */}
          <Button 
            className={cn(
              "w-full h-16 text-lg font-semibold rounded-xl shadow-lg active:scale-[0.98] transition-all",
              isClockedIn 
                ? "bg-gradient-to-r from-red-500 to-red-400 hover:from-red-600 hover:to-red-500" 
                : isClockedOut 
                  ? "bg-[#2a2a4a] text-[#666] cursor-not-allowed"
                  : "bg-gradient-to-r from-[#6C63FF] to-[#8b5cf6] hover:from-[#5a52d5] hover:to-[#7c3aed]"
            )}
            onClick={handleClockAction}
            disabled={isLoading || isClockedOut}
          >
            {isLoading ? (
              <Loader2 className="w-6 h-6 animate-spin" />
            ) : (
              <>
                {isClockedIn ? (
                  <><Clock className="w-6 h-6 mr-2" /> Clock Out</>
                ) : isClockedOut ? (
                  <><CheckCircle2 className="w-6 h-6 mr-2" /> Done for Today</>
                ) : (
                  <><Clock className="w-6 h-6 mr-2" /> Clock In Now</>
                )}
              </>
            )}
          </Button>

          {/* GPS Warning */}
          {gpsStatus === 'error' && (
            <p className="text-xs text-amber-400 text-center mt-3 flex items-center justify-center gap-1">
              <AlertTriangle className="w-3 h-3" />
              GPS unavailable. Using web check-in.
            </p>
          )}
        </CardContent>
      </Card>

      {/* Method Selection Tabs */}
      <Tabs value={activeMethod} onValueChange={(v) => setActiveMethod(v as 'gps' | 'qr')}>
        <TabsList className="grid w-full grid-cols-2 bg-[#1e1e35] border border-[#2a2a4a] p-1 rounded-xl h-14">
          <TabsTrigger 
            value="gps" 
            className="rounded-lg data-[state=active]:bg-[#6C63FF] data-[state=active]:text-white h-full text-sm font-medium"
          >
            <Navigation className="w-4 h-4 mr-2" />
            GPS
          </TabsTrigger>
          <TabsTrigger 
            value="qr" 
            className="rounded-lg data-[state=active]:bg-[#6C63FF] data-[state=active]:text-white h-full text-sm font-medium"
          >
            <QrCode className="w-4 h-4 mr-2" />
            QR Code
          </TabsTrigger>
        </TabsList>

        {/* QR Method */}
        <TabsContent value="qr" className="mt-4">
          <Card className="bg-[#1e1e35] border-[#2a2a4a]">
            <CardContent className="p-6">
              {!showScanner ? (
                <div className="text-center py-8">
                  <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-[#6C63FF]/20 to-[#6C63FF]/5 flex items-center justify-center mx-auto mb-6 border border-[#6C63FF]/30">
                    <Smartphone className="w-12 h-12 text-[#6C63FF]" />
                  </div>
                  <h3 className="text-lg font-semibold text-[#e0e0f0] mb-2">Scan QR Code</h3>
                  <p className="text-[#888] text-sm mb-6 max-w-xs mx-auto">
                    Point your camera at the QR code displayed at the office entrance
                  </p>
                  <Button 
                    onClick={() => setShowScanner(true)}
                    className="w-full h-14 bg-[#6C63FF] hover:bg-[#5a52d5] rounded-xl text-base"
                    disabled={isClockedOut}
                  >
                    <Scan className="w-5 h-5 mr-2" />
                    Open Camera
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  <div 
                    id="qr-reader" 
                    ref={scannerContainerRef}
                    className="rounded-xl overflow-hidden"
                  />
                  <Button 
                    variant="outline" 
                    onClick={() => setShowScanner(false)}
                    className="w-full h-12 border-[#2a2a4a] text-[#e0e0f0] hover:bg-[#2a2a4a] rounded-xl"
                  >
                    Cancel
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* GPS Info */}
        <TabsContent value="gps" className="mt-4">
          <Card className="bg-[#1e1e35] border-[#2a2a4a]">
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-[#6C63FF]/20 flex items-center justify-center flex-shrink-0">
                  <Info className="w-6 h-6 text-[#6C63FF]" />
                </div>
                <div>
                  <h3 className="font-semibold text-[#e0e0f0] mb-1">How GPS Check-in Works</h3>
                  <ul className="text-sm text-[#888] space-y-2">
                    <li className="flex items-start gap-2">
                      <ChevronRight className="w-4 h-4 text-[#6C63FF] flex-shrink-0 mt-0.5" />
                      <span>Your location is verified against the office (Lagos)</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <ChevronRight className="w-4 h-4 text-[#6C63FF] flex-shrink-0 mt-0.5" />
                      <span>You must be within 300m of the office</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <ChevronRight className="w-4 h-4 text-[#6C63FF] flex-shrink-0 mt-0.5" />
                      <span>Late arrivals after 8:10 AM are flagged</span>
                    </li>
                  </ul>
                </div>
              </div>

              {/* Office Location Card */}
              <div className="mt-6 p-4 bg-[#0f0f1a] rounded-xl border border-[#2a2a4a]">
                <div className="flex items-center gap-3 mb-3">
                  <MapPin className="w-5 h-5 text-[#6C63FF]" />
                  <span className="font-medium text-[#e0e0f0]">Office Location</span>
                </div>
                <p className="text-sm text-[#888]">Lagos, Nigeria</p>
                <p className="text-xs text-[#666] font-mono mt-1">
                  6.5244° N, 3.3792° E
                </p>
                <div className="mt-3 flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-xs text-emerald-400">300m radius active</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
