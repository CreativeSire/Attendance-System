import { useState, useCallback, useEffect, useRef } from 'react';
import type { QRSession } from '@/types';

// Generate a random QR code
function generateQRCode(): string {
  return Math.random().toString(36).substring(2, 15) + 
         Math.random().toString(36).substring(2, 15);
}

export function useQRCodeGenerator(officeLocation: { lat: number; lng: number }, refreshInterval: number = 5) {
  const [currentQR, setCurrentQR] = useState<QRSession | null>(null);
  const [timeRemaining, setTimeRemaining] = useState<number>(refreshInterval * 60);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const countdownRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const generateNewQR = useCallback(() => {
    const now = new Date();
    const expiresAt = new Date(now.getTime() + refreshInterval * 60 * 1000);
    
    const newSession: QRSession = {
      id: Date.now().toString(),
      code: generateQRCode(),
      createdAt: now.toISOString(),
      expiresAt: expiresAt.toISOString(),
      location: officeLocation
    };
    
    setCurrentQR(newSession);
    setTimeRemaining(refreshInterval * 60);
    
    return newSession;
  }, [officeLocation, refreshInterval]);

  const startQRGenerator = useCallback(() => {
    // Generate initial QR
    generateNewQR();
    
    // Set up interval to regenerate QR code
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }
    
    intervalRef.current = setInterval(() => {
      generateNewQR();
    }, refreshInterval * 60 * 1000);

    // Set up countdown timer
    if (countdownRef.current) {
      clearInterval(countdownRef.current);
    }
    
    countdownRef.current = setInterval(() => {
      setTimeRemaining(prev => {
        if (prev <= 1) {
          return refreshInterval * 60;
        }
        return prev - 1;
      });
    }, 1000);
  }, [generateNewQR, refreshInterval]);

  const stopQRGenerator = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    if (countdownRef.current) {
      clearInterval(countdownRef.current);
      countdownRef.current = null;
    }
  }, []);

  const verifyQRCode = useCallback((scannedCode: string): boolean => {
    if (!currentQR) return false;
    
    const now = new Date();
    const expiresAt = new Date(currentQR.expiresAt);
    
    // Check if QR code is still valid
    if (now > expiresAt) {
      return false;
    }
    
    return currentQR.code === scannedCode;
  }, [currentQR]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
      if (countdownRef.current) clearInterval(countdownRef.current);
    };
  }, []);

  return {
    currentQR,
    timeRemaining,
    generateNewQR,
    startQRGenerator,
    stopQRGenerator,
    verifyQRCode,
    isValid: !!currentQR && new Date() < new Date(currentQR.expiresAt)
  };
}

// Hook for QR code scanning
export function useQRScanner() {
  const [scanResult, setScanResult] = useState<string | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const startScanning = useCallback(() => {
    setIsScanning(true);
    setError(null);
    setScanResult(null);
  }, []);

  const stopScanning = useCallback(() => {
    setIsScanning(false);
  }, []);

  const handleScan = useCallback((result: string) => {
    setScanResult(result);
    setIsScanning(false);
    return result;
  }, []);

  const handleError = useCallback((err: Error) => {
    setError(err.message);
    setIsScanning(false);
  }, []);

  const resetScan = useCallback(() => {
    setScanResult(null);
    setError(null);
    setIsScanning(false);
  }, []);

  return {
    scanResult,
    isScanning,
    error,
    startScanning,
    stopScanning,
    handleScan,
    handleError,
    resetScan
  };
}
