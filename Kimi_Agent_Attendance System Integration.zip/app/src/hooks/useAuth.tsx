import React, { createContext, useContext, useState, useCallback, type ReactNode } from 'react';
import type { User, UserRole } from '@/types';

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  isAuthenticated: boolean;
  hasRole: (roles: UserRole[]) => boolean;
  employees: User[];
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Nigerian employee data from user's code
export const MOCK_EMPLOYEES: User[] = [
  {
    id: '1',
    name: 'Amara Okafor',
    email: 'amara@dala.ng',
    role: 'admin',
    department: 'Sales',
    employeeId: 'DALA001',
    hourlyRate: 71, // ~₦150,000/month / 22 days / 8 hours
    officeLocation: {
      lat: 6.5244,
      lng: 3.3792,
      radius: 300,
      address: 'Lagos, Nigeria'
    }
  },
  {
    id: '2',
    name: 'Chidi Nweze',
    email: 'chidi@dala.ng',
    role: 'manager',
    department: 'Operations',
    employeeId: 'DALA002',
    hourlyRate: 57, // ~₦120,000/month
    officeLocation: {
      lat: 6.5244,
      lng: 3.3792,
      radius: 300,
      address: 'Lagos, Nigeria'
    }
  },
  {
    id: '3',
    name: 'Fatima Bello',
    email: 'fatima@dala.ng',
    role: 'staff',
    department: 'Finance',
    employeeId: 'DALA003',
    hourlyRate: 67, // ~₦140,000/month
    officeLocation: {
      lat: 6.5244,
      lng: 3.3792,
      radius: 300,
      address: 'Lagos, Nigeria'
    }
  },
  {
    id: '4',
    name: 'Emeka Eze',
    email: 'emeka@dala.ng',
    role: 'staff',
    department: 'Technology',
    employeeId: 'DALA004',
    hourlyRate: 62, // ~₦130,000/month
    officeLocation: {
      lat: 6.5244,
      lng: 3.3792,
      radius: 300,
      address: 'Lagos, Nigeria'
    }
  },
  {
    id: '5',
    name: 'Ngozi Adeyemi',
    email: 'ngozi@dala.ng',
    role: 'manager',
    department: 'HR',
    employeeId: 'DALA005',
    hourlyRate: 76, // ~₦160,000/month
    officeLocation: {
      lat: 6.5244,
      lng: 3.3792,
      radius: 300,
      address: 'Lagos, Nigeria'
    }
  }
];

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  const login = useCallback(async (email: string, password: string): Promise<boolean> => {
    const foundUser = MOCK_EMPLOYEES.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (foundUser && password === 'password') {
      setUser(foundUser);
      localStorage.setItem('dala_user', JSON.stringify(foundUser));
      return true;
    }
    return false;
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    localStorage.removeItem('dala_user');
  }, []);

  const hasRole = useCallback((roles: UserRole[]): boolean => {
    if (!user) return false;
    return roles.includes(user.role);
  }, [user]);

  React.useEffect(() => {
    const stored = localStorage.getItem('dala_user');
    if (stored) {
      setUser(JSON.parse(stored));
    }
  }, []);

  return (
    <AuthContext.Provider value={{
      user,
      login,
      logout,
      isAuthenticated: !!user,
      hasRole,
      employees: MOCK_EMPLOYEES
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
