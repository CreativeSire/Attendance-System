import { useState, useCallback } from 'react';
import type { AttendanceRecord, LeaveRequest } from '@/types';
import { format, parseISO, startOfWeek, endOfWeek, isWithinInterval } from 'date-fns';
import { MOCK_EMPLOYEES } from './useAuth';

// Nigerian payroll constants
const WORKING_DAYS_PER_MONTH = 22;
const WORK_START_HOUR = 8;
const LATE_THRESHOLD_MINUTES = 10; // 8:10 AM
const LATE_PENALTY_RATE = 0.1; // 10% of daily rate per late day

// Helper functions
const getToday = () => new Date().toISOString().split('T')[0];
const fmtTime = (iso?: string) => iso ? new Date(iso).toLocaleTimeString('en-NG', { hour: '2-digit', minute: '2-digit' }) : '--:--';

// Generate mock attendance data for Nigerian team
const generateMockData = (): AttendanceRecord[] => {
  const records: AttendanceRecord[] = [];
  const today = new Date();
  
  const staffIds = MOCK_EMPLOYEES.filter(e => e.role === 'staff').map(e => e.id);
  const staffNames = MOCK_EMPLOYEES.filter(e => e.role === 'staff').map(e => e.name);
  
  for (let i = 0; i < 30; i++) {
    const date = new Date(today);
    date.setDate(date.getDate() - i);
    const dateStr = format(date, 'yyyy-MM-dd');
    
    // Skip weekends
    if (date.getDay() === 0 || date.getDay() === 6) continue;
    
    staffIds.forEach((staffId, idx) => {
      const isLateRecord = Math.random() < 0.15;
      const isAbsent = Math.random() < 0.05;
      
      if (isAbsent) {
        records.push({
          id: `${staffId}-${dateStr}`,
          userId: staffId,
          userName: staffNames[idx],
          date: dateStr,
          status: 'absent',
          totalHours: 0,
          isLate: false
        });
      } else {
        const baseHour = WORK_START_HOUR;
        const lateMinutes = isLateRecord ? Math.floor(Math.random() * 30) + 5 : 0;
        
        const clockInHour = baseHour;
        const clockInMinute = lateMinutes;
        
        const clockOutHour = 17 + Math.floor(Math.random() * 2);
        const clockOutMinute = Math.floor(Math.random() * 60);
        
        const totalHours = (clockOutHour - clockInHour) + (clockOutMinute - clockInMinute) / 60;
        
        // Create ISO timestamp
        const clockInISO = new Date(date);
        clockInISO.setHours(clockInHour, clockInMinute, 0, 0);
        
        records.push({
          id: `${staffId}-${dateStr}`,
          userId: staffId,
          userName: staffNames[idx],
          date: dateStr,
          clockIn: {
            time: fmtTime(clockInISO.toISOString()),
            location: { lat: 6.5244, lng: 3.3792 },
            method: 'gps'
          },
          status: isLateRecord ? 'late' : 'present',
          totalHours: Math.round(totalHours * 100) / 100,
          isLate: isLateRecord,
          lateMinutes: isLateRecord ? lateMinutes : 0
        });
      }
    });
  }
  
  return records;
};

// Mock leave requests
const MOCK_LEAVES: LeaveRequest[] = [
  {
    id: '1',
    userId: '3',
    userName: 'Fatima Bello',
    type: 'sick',
    startDate: getToday(),
    endDate: getToday(),
    reason: 'Not feeling well',
    status: 'pending',
    requestedAt: format(new Date(), 'yyyy-MM-dd HH:mm:ss')
  },
  {
    id: '2',
    userId: '4',
    userName: 'Emeka Eze',
    type: 'vacation',
    startDate: format(new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd'),
    endDate: format(new Date(Date.now() + 10 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd'),
    reason: 'Family trip',
    status: 'approved',
    requestedAt: format(new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd HH:mm:ss'),
    approvedBy: 'Ngozi Adeyemi',
    approvedAt: format(new Date(Date.now() - 1 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd HH:mm:ss')
  }
];

export function useAttendance() {
  const [records, setRecords] = useState<AttendanceRecord[]>(generateMockData());
  const [leaves, setLeaves] = useState<LeaveRequest[]>(MOCK_LEAVES);
  const [isClockedIn, setIsClockedIn] = useState<Record<string, boolean>>({});

  const clockIn = useCallback((userId: string, userName: string, location: { lat: number; lng: number }, method: 'gps' | 'qr' | 'manual') => {
    const today = getToday();
    const now = new Date();
    const timeStr = fmtTime(now.toISOString());
    
    const existingIndex = records.findIndex(r => r.userId === userId && r.date === today);
    
    const workStartTime = `${WORK_START_HOUR.toString().padStart(2, '0')}:00`;
    const [workHour, workMinute] = workStartTime.split(':').map(Number);
    const [currentHour, currentMinute] = timeStr.split(':').map(Number);
    
    const workMinutes = workHour * 60 + workMinute;
    const currentMinutes = currentHour * 60 + currentMinute;
    const gracePeriod = LATE_THRESHOLD_MINUTES;
    
    const isLateRecord = currentMinutes > workMinutes + gracePeriod;
    const lateMinutes = isLateRecord ? currentMinutes - workMinutes : 0;
    
    const newRecord: AttendanceRecord = {
      id: `${userId}-${today}`,
      userId,
      userName,
      date: today,
      clockIn: {
        time: timeStr,
        location,
        method
      },
      status: isLateRecord ? 'late' : 'present',
      totalHours: 0,
      isLate: isLateRecord,
      lateMinutes
    };
    
    if (existingIndex >= 0) {
      const updated = [...records];
      updated[existingIndex] = { ...updated[existingIndex], ...newRecord };
      setRecords(updated);
    } else {
      setRecords(prev => [newRecord, ...prev]);
    }
    
    setIsClockedIn(prev => ({ ...prev, [userId]: true }));
    return { success: true, isLate: isLateRecord, lateMinutes };
  }, [records]);

  const clockOut = useCallback((userId: string, location: { lat: number; lng: number }, method: 'gps' | 'qr' | 'manual') => {
    const today = getToday();
    const now = new Date();
    const timeStr = fmtTime(now.toISOString());
    
    const existingIndex = records.findIndex(r => r.userId === userId && r.date === today);
    
    if (existingIndex >= 0) {
      const record = records[existingIndex];
      const clockInTime = record.clockIn?.time;
      
      let totalHours = 0;
      if (clockInTime) {
        const [inHour, inMinute] = clockInTime.split(':').map(Number);
        const [outHour, outMinute] = timeStr.split(':').map(Number);
        totalHours = (outHour - inHour) + (outMinute - inMinute) / 60;
      }
      
      const updated = [...records];
      updated[existingIndex] = {
        ...record,
        clockOut: {
          time: timeStr,
          location,
          method
        },
        totalHours: Math.round(totalHours * 100) / 100
      };
      setRecords(updated);
      setIsClockedIn(prev => ({ ...prev, [userId]: false }));
      return { success: true, totalHours: Math.round(totalHours * 100) / 100 };
    }
    
    return { success: false, error: 'No clock-in record found' };
  }, [records]);

  const markAbsent = useCallback((userId: string, userName: string) => {
    const today = getToday();
    
    const existingIndex = records.findIndex(r => r.userId === userId && r.date === today);
    
    if (existingIndex >= 0) {
      return { success: false, error: 'Already has a record for today' };
    }
    
    const newRecord: AttendanceRecord = {
      id: `${userId}-${today}`,
      userId,
      userName,
      date: today,
      status: 'absent',
      totalHours: 0,
      isLate: false
    };
    
    setRecords(prev => [newRecord, ...prev]);
    return { success: true };
  }, [records]);

  const getTodayRecord = useCallback((userId: string): AttendanceRecord | undefined => {
    const today = getToday();
    return records.find(r => r.userId === userId && r.date === today);
  }, [records]);

  const getUserRecords = useCallback((userId: string, startDate?: string, endDate?: string): AttendanceRecord[] => {
    let userRecords = records.filter(r => r.userId === userId);
    
    if (startDate && endDate) {
      userRecords = userRecords.filter(r => 
        r.date >= startDate && r.date <= endDate
      );
    }
    
    return userRecords.sort((a, b) => b.date.localeCompare(a.date));
  }, [records]);

  const getAllRecords = useCallback((date?: string): AttendanceRecord[] => {
    if (date) {
      return records.filter(r => r.date === date).sort((a, b) => b.date.localeCompare(a.date));
    }
    return records.sort((a, b) => b.date.localeCompare(a.date));
  }, [records]);

  const getWeeklyReport = useCallback((userId?: string) => {
    const today = new Date();
    const weekStart = startOfWeek(today, { weekStartsOn: 1 });
    const weekEnd = endOfWeek(today, { weekStartsOn: 1 });
    
    const weekRecords = records.filter(r => {
      const recordDate = parseISO(r.date);
      const inWeek = isWithinInterval(recordDate, { start: weekStart, end: weekEnd });
      return userId ? inWeek && r.userId === userId : inWeek;
    });
    
    const summary = weekRecords.reduce((acc, record) => {
      if (!acc[record.userId]) {
        acc[record.userId] = {
          userId: record.userId,
          userName: record.userName,
          totalHours: 0,
          daysPresent: 0,
          daysLate: 0,
          daysAbsent: 0
        };
      }
      
      acc[record.userId].totalHours += record.totalHours;
      if (record.status === 'present') acc[record.userId].daysPresent++;
      if (record.status === 'late') acc[record.userId].daysLate++;
      if (record.status === 'absent') acc[record.userId].daysAbsent++;
      
      return acc;
    }, {} as Record<string, any>);
    
    return Object.values(summary);
  }, [records]);

  const requestLeave = useCallback((leave: Omit<LeaveRequest, 'id' | 'status' | 'requestedAt'>) => {
    const newLeave: LeaveRequest = {
      ...leave,
      id: Date.now().toString(),
      status: 'pending',
      requestedAt: format(new Date(), 'yyyy-MM-dd HH:mm:ss')
    };
    setLeaves(prev => [newLeave, ...prev]);
    return { success: true };
  }, []);

  const approveLeave = useCallback((leaveId: string, approvedBy: string) => {
    setLeaves(prev => prev.map(leave => 
      leave.id === leaveId 
        ? { 
            ...leave, 
            status: 'approved', 
            approvedBy, 
            approvedAt: format(new Date(), 'yyyy-MM-dd HH:mm:ss') 
          }
        : leave
    ));
    return { success: true };
  }, []);

  const rejectLeave = useCallback((leaveId: string) => {
    setLeaves(prev => prev.map(leave => 
      leave.id === leaveId 
        ? { ...leave, status: 'rejected' }
        : leave
    ));
    return { success: true };
  }, []);

  const getUserLeaves = useCallback((userId: string) => {
    return leaves.filter(l => l.userId === userId).sort((a, b) => 
      b.requestedAt.localeCompare(a.requestedAt)
    );
  }, [leaves]);

  const getPendingLeaves = useCallback(() => {
    return leaves.filter(l => l.status === 'pending').sort((a, b) => 
      b.requestedAt.localeCompare(a.requestedAt)
    );
  }, [leaves]);

  const getLateRecords = useCallback((date?: string) => {
    let lateRecords = records.filter(r => r.isLate);
    if (date) {
      lateRecords = lateRecords.filter(r => r.date === date);
    }
    return lateRecords.sort((a, b) => b.date.localeCompare(a.date));
  }, [records]);

  // Nigerian payroll calculation
  const calculatePayroll = useCallback((userId: string, monthlySalary: number, period: string) => {
    const userRecords = records.filter(r => r.userId === userId && r.date.startsWith(period));
    
    // Count unique days present
    const presentDays = new Set(userRecords.filter(r => r.status === 'present' || r.status === 'late').map(r => r.date)).size;
    
    // Total hours worked
    const totalHours = userRecords.reduce((sum, r) => sum + r.totalHours, 0);
    
    // Late count
    const lateCount = userRecords.filter(r => r.isLate).length;
    
    // Nigerian payroll calculation
    const dailyRate = monthlySalary / WORKING_DAYS_PER_MONTH;
    const grossPay = presentDays * dailyRate;
    const latePenalty = lateCount * (dailyRate * LATE_PENALTY_RATE);
    const netPay = Math.max(0, grossPay - latePenalty);
    
    return {
      userId,
      presentDays,
      totalHours: Math.round(totalHours * 10) / 10,
      lateCount,
      dailyRate: Math.round(dailyRate),
      grossPay: Math.round(grossPay),
      latePenalty: Math.round(latePenalty),
      netPay: Math.round(netPay),
      monthlySalary
    };
  }, [records]);

  const fmtNaira = (n: number) => `₦${n.toLocaleString()}`;

  return {
    records,
    leaves,
    isClockedIn,
    clockIn,
    clockOut,
    markAbsent,
    getTodayRecord,
    getUserRecords,
    getAllRecords,
    getWeeklyReport,
    requestLeave,
    approveLeave,
    rejectLeave,
    getUserLeaves,
    getPendingLeaves,
    getLateRecords,
    calculatePayroll,
    fmtNaira,
    WORKING_DAYS_PER_MONTH,
    LATE_PENALTY_RATE
  };
}
